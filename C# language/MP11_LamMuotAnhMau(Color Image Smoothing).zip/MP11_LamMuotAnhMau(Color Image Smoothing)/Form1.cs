﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MP11_LamMuotAnhMau_Color_Image_Smoothing_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // load hinh .pjg tu file 
            // chuyen bien hinh goc thanh bien toan cuc de de su dung cho cac ham khac 
            Bitmap hinhgoc = new Bitmap(@"E:\Visual Studio\Thi giac may\lena_color.jpg");
            picBox_hinhgoc.Image = hinhgoc;
            // ham làm mượt ảnh 
            Bitmap SmoothingImage3x3=ColorImageSmoothing3x3(hinhgoc);
            Bitmap SmoothingImage5x5 = ColorImageSmoothing5x5(hinhgoc);
            Bitmap SmoothingImage7x7 = ColorImageSmoothing7x7(hinhgoc);
            Bitmap SmoothingImage9x9 = ColorImageSmoothing9x9(hinhgoc);

            // hiển thị ảnh lên picbox
            picBox_Mask3x3.Image = SmoothingImage3x3;
            picBox_Mask5x5.Image = SmoothingImage5x5;
            picBox_Mask7x7.Image = SmoothingImage7x7;
            picBox_Mask9x9.Image = SmoothingImage9x9;



        }
        // làm mượt ảnh với phương pháp mặt nạ 3x3
        public Bitmap ColorImageSmoothing3x3(Bitmap hinhgoc)
        {
            Bitmap SmoothingImage3x3 = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            // doi voi mat na 3x3 de de lap trinh co the bo qua cac viền bên ngoài của các ảnh 
            // do đó ta thể xét từ phần từ thứ 1 đến phần tử thứ width-1 và height cũng tương tự
            for (int x = 1; x < hinhgoc.Width - 1; x++)
            {
                for (int y = 1; y < hinhgoc.Height - 1; y++)
                {   // các biến này khai báo ra để chứa các giá trị cộng dồn của các điểm ảnh nằm trong mặt nạ 
                    // Do đó phải được khai báo kiêu dữ liệu là int để có thể chứa các giá trị là số nguyên để chứa các pixel tương ứng 

                    int Rs = 0, Gs = 0, Bs = 0;
                    // tiền hành quét các điểm có trong mặt nạ
                    for (int i = x - 1; i <= x + 1; i++)
                        for (int j = y - 1; j <= y + 1; j++)
                        {
                            // lấy các giá trị điểm ảnh có trong mặt nạ 
                            Color color = hinhgoc.GetPixel(i, j);
                            byte R = color.R;
                            byte G = color.G;
                            byte B = color.B;

                            // cộng dồn các điểm ảnh có trong mặt nạ tương ứng
                             Rs += R;
                             Gs += G;
                             Bs += B;
                        }
                    byte K = 3 * 3;
                    Rs = (int)(Rs / K);
                    Gs=  (int)(Gs / K);
                    Bs = (int)(Bs / K);
                    // set các điểm đã làm mượt trên vào ảnh trong Bitmap
                    SmoothingImage3x3.SetPixel(x, y, Color.FromArgb(Rs,Gs,Bs));
                }
            }

            return SmoothingImage3x3;
        }
        // làm mượt ảnh với phương pháp mặt nạ 5x5
        public Bitmap ColorImageSmoothing5x5(Bitmap hinhgoc)
        {
            Bitmap SmoothingImage5x5 = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            // doi voi mat na 3x3 de de lap trinh co the bo qua cac viền bên ngoài của các ảnh 
            // do đó ta thể xét từ phần từ thứ 1 đến phần tử thứ width-2 và height cũng tương tự
            for (int x = 2; x < hinhgoc.Width - 2; x++)
            {
                for (int y = 2; y < hinhgoc.Height - 2; y++)
                {   // các biến này khai báo ra để chứa các giá trị cộng dồn của các điểm ảnh nằm trong mặt nạ 
                    // Do đó phải được khai báo kiêu dữ liệu là int để có thể chứa các giá trị là số nguyên để chứa các pixel tương ứng 

                    int Rs = 0, Gs = 0, Bs = 0;
                    // tiền hành quét các điểm có trong mặt nạ
                    for (int i = x - 2; i <= x + 2; i++)
                        for (int j = y - 2; j <= y + 2; j++)
                        {
                            // lấy các giá trị điểm ảnh có trong mặt nạ 
                            Color color = hinhgoc.GetPixel(i, j);
                            byte R = color.R;
                            byte G = color.G;
                            byte B = color.B;

                            // cộng dồn các điểm ảnh có trong mặt nạ tương ứng
                            Rs += R;
                            Gs += G;
                            Bs += B;
                        }
                    byte K = 5 * 5;
                    Rs = (int)(Rs / K);
                    Gs = (int)(Gs / K);
                    Bs = (int)(Bs / K);
                    // set các điểm đã làm mượt trên vào ảnh trong Bitmap
                    SmoothingImage5x5.SetPixel(x, y, Color.FromArgb(Rs, Gs, Bs));
                }
            }

            return SmoothingImage5x5;
        }
        // làm mượt ảnh với phương pháp mặt nạ 7x7
        public Bitmap ColorImageSmoothing7x7(Bitmap hinhgoc)
        {
            Bitmap SmoothingImage7x7 = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            // doi voi mat na 3x3 de de lap trinh co the bo qua cac viền bên ngoài của các ảnh 
            // do đó ta thể xét từ phần từ thứ 1 đến phần tử thứ width-3 và height cũng tương tự
            for (int x = 3; x < hinhgoc.Width - 3; x++)
            {
                for (int y = 3; y < hinhgoc.Height - 3; y++)
                {   // các biến này khai báo ra để chứa các giá trị cộng dồn của các điểm ảnh nằm trong mặt nạ 
                    // Do đó phải được khai báo kiêu dữ liệu là int để có thể chứa các giá trị là số nguyên để chứa các pixel tương ứng 

                    int Rs = 0, Gs = 0, Bs = 0;
                    // tiền hành quét các điểm có trong mặt nạ
                    for (int i = x - 3; i <= x + 3; i++)
                        for (int j = y - 3; j <= y + 3; j++)
                        {
                            // lấy các giá trị điểm ảnh có trong mặt nạ 
                            Color color = hinhgoc.GetPixel(i, j);
                            byte R = color.R;
                            byte G = color.G;
                            byte B = color.B;

                            // cộng dồn các điểm ảnh có trong mặt nạ tương ứng
                            Rs += R;
                            Gs += G;
                            Bs += B;
                        }
                    byte K = 7 * 7;
                    Rs = (int)(Rs / K);
                    Gs = (int)(Gs / K);
                    Bs = (int)(Bs / K);
                    // set các điểm đã làm mượt trên vào ảnh trong Bitmap
                    SmoothingImage7x7.SetPixel(x, y, Color.FromArgb(Rs, Gs, Bs));
                }
            }

            return SmoothingImage7x7;
        }
        // làm mượt ảnh với phương pháp mặt nạ 9x9
        public Bitmap ColorImageSmoothing9x9(Bitmap hinhgoc)
        {
            Bitmap SmoothingImage9x9 = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            // doi voi mat na 3x3 de de lap trinh co the bo qua cac viền bên ngoài của các ảnh 
            // do đó ta thể xét từ phần từ thứ 1 đến phần tử thứ width-4 và height cũng tương tự
            for (int x = 4; x < hinhgoc.Width - 4; x++)
            {
                for (int y = 4; y < hinhgoc.Height - 4; y++)
                {   // các biến này khai báo ra để chứa các giá trị cộng dồn của các điểm ảnh nằm trong mặt nạ 
                    // Do đó phải được khai báo kiêu dữ liệu là int để có thể chứa các giá trị là số nguyên để chứa các pixel tương ứng 

                    int Rs = 0, Gs = 0, Bs = 0;
                    // tiền hành quét các điểm có trong mặt nạ
                    for (int i = x - 4; i <= x + 4; i++)
                        for (int j = y - 4; j <= y + 4; j++)
                        {
                            // lấy các giá trị điểm ảnh có trong mặt nạ 
                            Color color = hinhgoc.GetPixel(i, j);
                            byte R = color.R;
                            byte G = color.G;
                            byte B = color.B;

                            // cộng dồn các điểm ảnh có trong mặt nạ tương ứng
                            Rs += R;
                            Gs += G;
                            Bs += B;
                        }
                    byte K = 9 * 9;
                    Rs = (int)(Rs / K);
                    Gs = (int)(Gs / K);
                    Bs = (int)(Bs / K);
                    // set các điểm đã làm mượt trên vào ảnh trong Bitmap
                    SmoothingImage9x9.SetPixel(x, y, Color.FromArgb(Rs, Gs, Bs));
                }
            }

            return SmoothingImage9x9;
        }
    }
}
