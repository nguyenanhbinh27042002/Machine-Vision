﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MP09_RGB2XYZ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // load hinh .pjg tu file 
            // chuyen bien hinh goc thanh bien toan cuc de de su dung cho cac ham khac 
            Bitmap hinhgoc = new Bitmap(@"E:\Visual Studio\Thi giac may\lena_color.jpg");
            picBox_Hinhgoc.Image = hinhgoc;
            List<Bitmap> XYZ = ChuyenDoiAnhRGBsangXYZ(hinhgoc);
            picBox_KenhX.Image = XYZ[0];
            picBox_KenhY.Image = XYZ[1];
            picBox_KenhZ.Image = XYZ[2];
            picBox_KenhXYZ.Image = XYZ[3];
        }
        public List<Bitmap> ChuyenDoiAnhRGBsangXYZ(Bitmap hinhgoc)
        {
            // tao mang LIST chua cac kenh mau chuyen doi 
            List<Bitmap> XYZ = new List<Bitmap>();
            // tao 3 kenh mau chua cac hinh XYZ
            Bitmap KX = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            Bitmap KY = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            Bitmap KZ = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            // tao kenh mau XYZ
            Bitmap XYZ_image = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            for(int x = 0; x < hinhgoc.Width; x++)
            {
                for (int y = 0; y < hinhgoc.Height; y++) 
                {
                    Color pixel = hinhgoc.GetPixel(x, y);
                    double R = pixel.R;
                    double G = pixel.G;
                    double B = pixel.G;

                    double X = (0.4124564 * R + 0.3575761 * G + 0.1804375 * B);
                    double Y = (0.2126729 * R + 0.7151522 * G + 0.0721750 * B);
                    double Z = (0.0193339 * R + 0.1191920 * G + 0.9503041 * B);

                    KX.SetPixel(x, y, Color.FromArgb((byte)X, (byte)X, (byte)X));
                    KY.SetPixel(x, y, Color.FromArgb((byte)Y, (byte)Y, (byte)Y));
                    KZ.SetPixel(x, y, Color.FromArgb((byte)Z, (byte)Z, (byte)Z));
                    XYZ_image.SetPixel(x, y, Color.FromArgb((byte)X, (byte)Y, (byte)Z));
                }
                XYZ.Add(KX);
                XYZ.Add(KY);
                XYZ.Add(KZ);
                XYZ.Add(XYZ_image);
            }
            return XYZ; 
        }
    }
}
