﻿namespace MP09_RGB2XYZ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBox_Hinhgoc = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.picBox_KenhX = new System.Windows.Forms.PictureBox();
            this.picBox_KenhY = new System.Windows.Forms.PictureBox();
            this.picBox_KenhZ = new System.Windows.Forms.PictureBox();
            this.picBox_KenhXYZ = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Hinhgoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_KenhX)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_KenhY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_KenhZ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_KenhXYZ)).BeginInit();
            this.SuspendLayout();
            // 
            // picBox_Hinhgoc
            // 
            this.picBox_Hinhgoc.Location = new System.Drawing.Point(27, 70);
            this.picBox_Hinhgoc.Name = "picBox_Hinhgoc";
            this.picBox_Hinhgoc.Size = new System.Drawing.Size(270, 270);
            this.picBox_Hinhgoc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_Hinhgoc.TabIndex = 0;
            this.picBox_Hinhgoc.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Hinh Goc";
            // 
            // picBox_KenhX
            // 
            this.picBox_KenhX.Location = new System.Drawing.Point(27, 440);
            this.picBox_KenhX.Name = "picBox_KenhX";
            this.picBox_KenhX.Size = new System.Drawing.Size(270, 270);
            this.picBox_KenhX.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_KenhX.TabIndex = 2;
            this.picBox_KenhX.TabStop = false;
            // 
            // picBox_KenhY
            // 
            this.picBox_KenhY.Location = new System.Drawing.Point(315, 440);
            this.picBox_KenhY.Name = "picBox_KenhY";
            this.picBox_KenhY.Size = new System.Drawing.Size(270, 270);
            this.picBox_KenhY.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_KenhY.TabIndex = 3;
            this.picBox_KenhY.TabStop = false;
            // 
            // picBox_KenhZ
            // 
            this.picBox_KenhZ.Location = new System.Drawing.Point(603, 440);
            this.picBox_KenhZ.Name = "picBox_KenhZ";
            this.picBox_KenhZ.Size = new System.Drawing.Size(270, 270);
            this.picBox_KenhZ.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_KenhZ.TabIndex = 4;
            this.picBox_KenhZ.TabStop = false;
            // 
            // picBox_KenhXYZ
            // 
            this.picBox_KenhXYZ.Location = new System.Drawing.Point(892, 440);
            this.picBox_KenhXYZ.Name = "picBox_KenhXYZ";
            this.picBox_KenhXYZ.Size = new System.Drawing.Size(270, 270);
            this.picBox_KenhXYZ.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_KenhXYZ.TabIndex = 5;
            this.picBox_KenhXYZ.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 405);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Kenh X";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(312, 405);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Kenh Y";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(600, 405);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Kenh Z";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(889, 405);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Kenh XYZ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1189, 722);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.picBox_KenhXYZ);
            this.Controls.Add(this.picBox_KenhZ);
            this.Controls.Add(this.picBox_KenhY);
            this.Controls.Add(this.picBox_KenhX);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picBox_Hinhgoc);
            this.Name = "Form1";
            this.Text = "Chuyen Anh Mau RGB sang XYZ";
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Hinhgoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_KenhX)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_KenhY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_KenhZ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_KenhXYZ)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBox_Hinhgoc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picBox_KenhX;
        private System.Windows.Forms.PictureBox picBox_KenhY;
        private System.Windows.Forms.PictureBox picBox_KenhZ;
        private System.Windows.Forms.PictureBox picBox_KenhXYZ;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

