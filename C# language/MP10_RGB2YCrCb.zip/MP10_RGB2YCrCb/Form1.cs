﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MP10_RGB2YCrCb
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // load hinh .pjg tu file 
            // chuyen bien hinh goc thanh bien toan cuc de de su dung cho cac ham khac 
            Bitmap hinhgoc = new Bitmap(@"E:\Visual Studio\Thi giac may\lena_color.jpg");
            picBox_hinhgoc.Image = hinhgoc;
            List<Bitmap> YCrCb = ChuyenDoiAnhRGBsangYCrCb(hinhgoc);
            picBox_kenhY.Image = YCrCb[0];
            picBox_kenhCr.Image = YCrCb[1];
            picBox_kenhCb.Image = YCrCb[2];
            picBox_YCrCb.Image = YCrCb[3];
        }
        public List<Bitmap> ChuyenDoiAnhRGBsangYCrCb(Bitmap hinhgoc)
        {
            // tao mang LIST chua cac kenh mau chuyen doi 
            List<Bitmap> YCrCb = new List<Bitmap>();
            // tao 3 kenh mau chua cac hinh XYZ
            Bitmap kenhY = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            Bitmap kenhCr = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            Bitmap kenhCb = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            // tao kenh mau XYZ
            Bitmap YCrCb_image = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            for (int x = 0; x < hinhgoc.Width; x++)
            {
                for (int y = 0; y < hinhgoc.Height; y++)
                {
                    Color pixel = hinhgoc.GetPixel(x, y);
                    double R = pixel.R;
                    double G = pixel.G;
                    double B = pixel.G;

                    double Y  = (16  + (65.738/256*R)  + (129.057/256*G) +   (25.064/256* B));
                    double Cr = (128 - (37.945/256*R) - (74.494/256*G)  +   (112.439/256*B));
                    double Cb= (128 + (112.439/256*R) - (94.154/256*G)  -   (18.258/256*B));

                    kenhY.SetPixel(x, y, Color.FromArgb((byte)Y, (byte)Y, (byte)Y));
                    kenhCr.SetPixel(x, y, Color.FromArgb((byte)Cr, (byte)Cr,(byte)Cr));
                    kenhCb.SetPixel(x, y, Color.FromArgb((byte)Cb, (byte)Cb, (byte)Cb));
                    YCrCb_image.SetPixel(x, y, Color.FromArgb((byte)Y, (byte)Cr, (byte)Cb));
                }
                YCrCb.Add(kenhY);
                YCrCb.Add(kenhCr);
                YCrCb.Add(kenhCb);
                YCrCb.Add(YCrCb_image);
            }
            return YCrCb;
        }
    }
}
