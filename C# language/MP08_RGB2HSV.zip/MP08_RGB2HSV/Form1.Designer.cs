﻿namespace MP08_RGB2HSV
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBox_hinhgoc = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.picBox_Hue = new System.Windows.Forms.PictureBox();
            this.picBox_Staturation = new System.Windows.Forms.PictureBox();
            this.picBox_Value = new System.Windows.Forms.PictureBox();
            this.picBox_HSV = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_hinhgoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Hue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Staturation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Value)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_HSV)).BeginInit();
            this.SuspendLayout();
            // 
            // picBox_hinhgoc
            // 
            this.picBox_hinhgoc.Location = new System.Drawing.Point(30, 104);
            this.picBox_hinhgoc.Name = "picBox_hinhgoc";
            this.picBox_hinhgoc.Size = new System.Drawing.Size(270, 270);
            this.picBox_hinhgoc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_hinhgoc.TabIndex = 0;
            this.picBox_hinhgoc.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Hinh Goc";
            // 
            // picBox_Hue
            // 
            this.picBox_Hue.Location = new System.Drawing.Point(30, 469);
            this.picBox_Hue.Name = "picBox_Hue";
            this.picBox_Hue.Size = new System.Drawing.Size(270, 270);
            this.picBox_Hue.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_Hue.TabIndex = 2;
            this.picBox_Hue.TabStop = false;
            // 
            // picBox_Staturation
            // 
            this.picBox_Staturation.Location = new System.Drawing.Point(316, 469);
            this.picBox_Staturation.Name = "picBox_Staturation";
            this.picBox_Staturation.Size = new System.Drawing.Size(270, 270);
            this.picBox_Staturation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_Staturation.TabIndex = 3;
            this.picBox_Staturation.TabStop = false;
            // 
            // picBox_Value
            // 
            this.picBox_Value.Location = new System.Drawing.Point(601, 469);
            this.picBox_Value.Name = "picBox_Value";
            this.picBox_Value.Size = new System.Drawing.Size(270, 270);
            this.picBox_Value.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_Value.TabIndex = 4;
            this.picBox_Value.TabStop = false;
            // 
            // picBox_HSV
            // 
            this.picBox_HSV.Location = new System.Drawing.Point(894, 469);
            this.picBox_HSV.Name = "picBox_HSV";
            this.picBox_HSV.Size = new System.Drawing.Size(270, 270);
            this.picBox_HSV.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_HSV.TabIndex = 5;
            this.picBox_HSV.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 432);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Kenh HUE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(322, 432);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Kenh STATURATION";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(598, 432);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Kenh VALUE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(891, 432);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Kenh HSV";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1185, 751);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.picBox_HSV);
            this.Controls.Add(this.picBox_Value);
            this.Controls.Add(this.picBox_Staturation);
            this.Controls.Add(this.picBox_Hue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picBox_hinhgoc);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picBox_hinhgoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Hue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Staturation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Value)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_HSV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBox_hinhgoc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picBox_Hue;
        private System.Windows.Forms.PictureBox picBox_Staturation;
        private System.Windows.Forms.PictureBox picBox_Value;
        private System.Windows.Forms.PictureBox picBox_HSV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

