﻿namespace RGB2HSI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picBox_hinhgoc = new System.Windows.Forms.PictureBox();
            this.picBox_HUE = new System.Windows.Forms.PictureBox();
            this.picBox_HSI = new System.Windows.Forms.PictureBox();
            this.picBox_Staturation = new System.Windows.Forms.PictureBox();
            this.picBox_Intensity = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_hinhgoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_HUE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_HSI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Staturation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Intensity)).BeginInit();
            this.SuspendLayout();
            // 
            // picBox_hinhgoc
            // 
            this.picBox_hinhgoc.Location = new System.Drawing.Point(52, 95);
            this.picBox_hinhgoc.Name = "picBox_hinhgoc";
            this.picBox_hinhgoc.Size = new System.Drawing.Size(270, 270);
            this.picBox_hinhgoc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_hinhgoc.TabIndex = 0;
            this.picBox_hinhgoc.TabStop = false;
            // 
            // picBox_HUE
            // 
            this.picBox_HUE.Location = new System.Drawing.Point(52, 432);
            this.picBox_HUE.Name = "picBox_HUE";
            this.picBox_HUE.Size = new System.Drawing.Size(270, 270);
            this.picBox_HUE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_HUE.TabIndex = 1;
            this.picBox_HUE.TabStop = false;
            // 
            // picBox_HSI
            // 
            this.picBox_HSI.Location = new System.Drawing.Point(880, 432);
            this.picBox_HSI.Name = "picBox_HSI";
            this.picBox_HSI.Size = new System.Drawing.Size(270, 270);
            this.picBox_HSI.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_HSI.TabIndex = 2;
            this.picBox_HSI.TabStop = false;
            // 
            // picBox_Staturation
            // 
            this.picBox_Staturation.Location = new System.Drawing.Point(328, 432);
            this.picBox_Staturation.Name = "picBox_Staturation";
            this.picBox_Staturation.Size = new System.Drawing.Size(270, 270);
            this.picBox_Staturation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_Staturation.TabIndex = 3;
            this.picBox_Staturation.TabStop = false;
            // 
            // picBox_Intensity
            // 
            this.picBox_Intensity.Location = new System.Drawing.Point(604, 432);
            this.picBox_Intensity.Name = "picBox_Intensity";
            this.picBox_Intensity.Size = new System.Drawing.Size(270, 270);
            this.picBox_Intensity.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox_Intensity.TabIndex = 4;
            this.picBox_Intensity.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Hinh goc";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 400);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Kenh HUE";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(325, 400);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Kenh STATURATION";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(601, 400);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Kenh INTENSITY";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(877, 400);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(62, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Kenh HSI";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 1055);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picBox_Intensity);
            this.Controls.Add(this.picBox_Staturation);
            this.Controls.Add(this.picBox_HSI);
            this.Controls.Add(this.picBox_HUE);
            this.Controls.Add(this.picBox_hinhgoc);
            this.Name = "Form1";
            this.Text = "Chuyen Doi Anh Mau RGB sang HSI";
            ((System.ComponentModel.ISupportInitialize)(this.picBox_hinhgoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_HUE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_HSI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Staturation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox_Intensity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picBox_hinhgoc;
        private System.Windows.Forms.PictureBox picBox_HUE;
        private System.Windows.Forms.PictureBox picBox_HSI;
        private System.Windows.Forms.PictureBox picBox_Staturation;
        private System.Windows.Forms.PictureBox picBox_Intensity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

