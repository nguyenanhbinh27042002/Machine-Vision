﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RGB2HSI
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
            // load hinh .pjg tu file 
            // chuyen bien hinh goc thanh bien toan cuc de de su dung cho cac ham khac 
            Bitmap hinhgoc = new Bitmap(@"E:\Visual Studio\Thi giac may\lena_color.jpg");
            picBox_hinhgoc.Image = hinhgoc;
            List<Bitmap>HSI=ChuyenDoiAnhRGBsangHSI(hinhgoc);
            picBox_HUE.Image = HSI[0];
            picBox_Staturation.Image = HSI[1];
            picBox_Intensity.Image = HSI[2];
            picBox_HSI.Image = HSI[3];
        }
        public List<Bitmap>ChuyenDoiAnhRGBsangHSI(Bitmap hinhgoc)
        {
            // tao mang LIST chua cac kenh mau chuyen doi 
            List<Bitmap> HSI = new List<Bitmap>() ;
            // tao 3 kenh mau chua cac hinh HSI
            Bitmap HUE = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            Bitmap STATURATION = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            Bitmap ITENSITY = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            // hinh HSI 
            Bitmap HSI_image = new Bitmap(hinhgoc.Width, hinhgoc.Height);
            for(int x = 0; x < hinhgoc.Width; x++)
            {
                for(int y = 0; y < hinhgoc.Height; y++)
                {
                    Color pixel = hinhgoc.GetPixel(x, y);
                    double R = pixel.R;
                    double G = pixel.G;
                    double B = pixel.B;

                    double t1 = ((R - G) + (R - B)) / 2;
                    double t2 = (R - G) * (R - G) + Math.Sqrt((R - B) * (G - B));
                    double thelta = Math.Acos(t1 / t2);
                    double H = 0;
                    if (B <= G)
                    {
                        H = thelta;
                    }
                    else
                        H = 2 * Math.PI - thelta;
                    // chuyen doi gia tri H tu radian sang degree 
                    H = H * 180 / Math.PI;
                   // cong thuc tinh gia tri Staturation 
                    double s = 1 - 3 * Math.Min(R, Math.Min(G, B)) / (R + G + B);
                    // chuyen doi S tu gia tri 0-1 sang 0-255
                    s = s * 255;
                    double I = (R + G + B) / 3;
                    HUE.SetPixel(x, y, Color.FromArgb((byte)H, (byte)H, (byte)H));
                    STATURATION.SetPixel(x, y, Color.FromArgb((byte)s, (byte)s, (byte)s));
                    ITENSITY.SetPixel(x, y, Color.FromArgb((byte)I, (byte)I, (byte)I));
                    HSI_image.SetPixel(x, y, Color.FromArgb((byte)H,(byte)s, (byte)I));
                }
                HSI.Add(HUE);
                HSI.Add(STATURATION);
                HSI.Add(ITENSITY);
                HSI.Add(HSI_image);
            }
            return HSI;
        }

    }
}
